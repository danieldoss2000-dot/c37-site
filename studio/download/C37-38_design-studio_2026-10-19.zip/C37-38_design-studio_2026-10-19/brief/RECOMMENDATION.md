# Studio recommendation (2026-10-19, after the hybrids and the movement check)

**Every design now passes the movement check**: from the front door and from the top of the stair, every room is reached
through a door-width clear path, nobody crosses a bedroom to reach another room, and no furniture cuts a room in two.
His dressing is a closed room in every design (except T1-X, kept as the "challenge the brief" comparison).

| Rank | Design | Score | Night route master → kids | Front door → guest WC | Kitchen → dining | Circulation G / F |
|---|---|---|---|---|---|---|
| 1 | **H4** H2 + the office's ideas (landing nook, curved hers, prayer apse) | **82.5** | 10.7 m | 2.0 m | 3.3 m | 16.6 % / ≈15 % |
| 2 | **H2** your master downstairs · equal thirds upstairs | **81.0** | 10.7 m | 2.0 m | 3.3 m | 16.6 % / 14.5 % |
| 1 | T2-B Equal thirds | 81.0 | 10.7 m | 2.4 m | 2.5 m | 14.3 % / 14.5 % |
| 3 | **H3** folded suite · equal kids (bold) | 80.0 | 12.5 m | 2.4 m | 2.8 m | 13.6 % / 15.0 % |
| 4 | **H1** family side · guest side · equal thirds | 78.5 | 10.7 m | 2.6 m | 1.8 m | 17.8 % / 14.5 % |
| 5 | T1-R3 master, round 3 | 76.0 | 13.0 m | 2.0 m | 3.3 m | 16.6 % / 18.0 % |

**Blind check (19 Oct evening):** three independent reviewers scored every first floor without names. H4's first floor and T2-B's (= H2's) tied at **77.5**; the studio's own 81–82.5 was about 5 points generous. The office's five plans scored 51–56 against your brief: see BLIND-REVIEW-2026-10-19.md. The recommendation below does not change.

**Recommendation: develop H4 (or H2 without the office extras) or H3 with the architects; pick by temperament.** H4 adds the best ideas from the office's five proposals (19 Oct) to H2.

- **H2** is the calm one: your own ground floor, developed (kitchen with the street window and island, 45° vestibule,
  TV living + garden lounge, garden-access guest WC), under the equal-thirds first floor. Least building risk.
- **H3** is the bold one: curved glass vestibule, walnut pivot wall to the kitchen, curved dining wall, a 45° folded
  walnut suite with a quarter-circle shower, and lofts — over the same equal kids wing.
- **H1** if receiving guests in a closable salon matters more than corridor efficiency downstairs.

**One site check decides the kids bath in H1/H2/H3/T2-B**: the W2 stack position and whether a ~1.5 m raised-floor drain
run (or a chase in the wall below) is acceptable. If not, the bath shifts ~1 m onto the stack; the equity survives.

**Next:** choose a design (or a hybrid of hybrids), hand the package to the architects, and we take the chosen plan into Revit.
