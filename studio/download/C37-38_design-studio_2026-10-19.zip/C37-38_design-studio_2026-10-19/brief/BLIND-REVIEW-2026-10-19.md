# Blind re-review of every first floor (19 Oct 2026)

Daniel asked whether the studio's scale was off for the office drawings. To check, the five office first floors were redrawn in the studio engine (same colours, furniture, measurements and movement check as every studio design; ground floor = H4's for all five, so only the first floor differs), and **all 15 distinct first floors were scored blind** by three independent reviewers: a residential architect, a family-life interior planner and a cost/build engineer. They saw only lettered plans A–O, the life-stage sheets, the measured numbers and the brief; no names, no authors, no earlier scores. Same 7 criteria and weights as BRIEF section 6, first floor only.

| Rank | Design | Drawn by | Architect | Family planner | Build engineer | **Blind average** | Studio's earlier score |
|---|---|---|---|---|---|---|---|
| 1 | **T2-B** Equal thirds | studio | 78.5 | 80.2 | 73.8 | **77.5** | 81.0 |
| 2 | **H4** H2 + the office's ideas | studio | 79.0 | 79.8 | 73.8 | **77.5** | 82.5 |
| 3 | **T1-X** Challenge the brief | studio | 76.0 | 74.5 | 75.2 | **75.2** | 76.0 |
| 4 | **T2-A** Family side · Guest side | studio | 80.8 | 73.5 | 71.2 | **75.2** | 75.0 |
| 5 | **T1-R1** Master plan, round 1 — the council's fixes | studio | 77.5 | 75.0 | 72.8 | **75.1** | 72.0 |
| 6 | **H3** Folded suite · equal kids | studio | 76.0 | 76.8 | 72.5 | **75.1** | 80.0 |
| 7 | **T1-R3** Master plan, round 3 — off the grid where it pays | studio | 76.5 | 72.0 | 69.0 | **72.5** | 76.0 |
| 8 | **T2-C** Soft courtyard | studio | 71.5 | 71.5 | 65.5 | **69.5** | 71.0 |
| 9 | **T2-D** Folded house | studio | 68.0 | 70.8 | 67.0 | **68.6** | 74.5 |
| 10 | **T0** Master plan as drawn (baseline) | you + architect | 70.5 | 64.2 | 63.8 | **66.2** | 64.0 |
| 11 | **O2** Office KK 2 — island dressing | office | 55.5 | 56.0 | 57.5 | **56.3** | 61.5 |
| 12 | **O5** Office Angles 2 — curved prayer room | office | 54.0 | 57.2 | 52.8 | **54.7** | 63.5 |
| 13 | **O4** Office Angles 1 — diagonal dressing | office | 54.2 | 55.2 | 52.2 | **53.9** | 58.5 |
| 14 | **O3** Office KK 3 — master on the terrace | office | 50.5 | 51.0 | 54.2 | **51.9** | 65 |
| 15 | **O1** Office KK 1 — family living | office | 49.2 | 52.5 | 51.5 | **51.1** | 64 |

H1 and H2 share T2-B's first floor; T1-R2 / R2W share T1-R3's, so they were not scored twice.

## What it says

1. **The three reviewers agree with each other** (spread ≤ 7 points on any plan) and all three put the five office plans at the bottom (51–56), below your master as drawn (66).
2. **The studio's scale was off in both directions.** The earlier office scores (58.5–65) were read off the images and were, if anything, kind. But the studio was also generous to its own hybrids: H4 scored 82.5 by the studio and 77.5 blind; H2/T2-B 81 → 77.5. The real gap between the best studio plans and the office plans is about 20 points, not 15.
3. **The gap is the brief, not the drawing quality.** The office plans are clean, buildable and on the drain stacks, with low circulation (O3 12.5 %, O2 13 %). They lose because they answer a different brief: an upstairs family living room (your brief: not needed), two children sharing a double room at 8.8 m² each while the third gets ~15 m² (brief: equal m²), the kids bath only from the corridor (brief: a door from each room), and in O2/O3 a lounge you can only reach through the master bedroom. Every reviewer named the same thing: the top plans turn the garden-east room into a suite lounge with its own shower and a landing door, so it becomes the third child's bedroom with no building work.
4. **If you and Karen actually want an upstairs family living room,** that is a change to the brief, and the office plans would rise. Say so and the studio re-scores everything against the new brief.

## The office plans, one line each (from the three reviewers)

- **O1 Office KK 1 — family living** · blind 51.1 · best: His and hers are separate closed rooms along the west bay. · worst: Only 4.6 m of wardrobe, hers dressing mostly unreachable behind furniture, no suite door, kids bath only off the corridor
- **O2 Office KK 2 — island dressing** · blind 56.3 · best: Big 13 m2 walk-in dressing and a garden lounge with real garden light. · worst: No laundry room at all; garden lounge only through the master bedroom so it can never become a child's room; two lounges with no WC
- **O3 Office KK 3 — master on the terrace** · blind 51.9 · best: Master moved to the garden-terrace bay with a big island dressing: a bold hotel-suite gesture. · worst: Sitting room only through the master, no his/hers split, laundry is a cupboard, master shrunk to 14.7 m2 in the east bay, no suite door
- **O4 Office Angles 1 — diagonal dressing** · blind 53.9 · best: Hers dressing is a proper room and the playroom/mini-gym is well proportioned. · worst: Master suite pieces scattered across the landing (hers dressing and bath off a shared passage), narrow master entry, angled leftovers
- **O5 Office Angles 2 — curved prayer room** · blind 54.7 · best: Generous prayer room and a real playroom; clean kids zone on the street side. · worst: No suite door, his/hers open niches, kids bath only off the corridor, double room at 8.8 m2/child vs 15.2

Detailed per-criterion scores: docs/studio/scores.yaml (O1–O5 carry the blind averages). Measured numbers: docs/studio/FIRST-FLOOR-MEASURED.md.
