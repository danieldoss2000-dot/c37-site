# Office proposals, first floor (received 2026-10-19) — studio review

Five first-floor layouts by the engineering architects at the office. Originals: `Kk_Proposals.pdf` (O1–O3, A2 sheet) and
`angles_proposals.pdf` (O4–O5, A3 sheet). One image per proposal: `O1_…png` … `O5_…png`.
Scored on the studio scorecard (docs/studio/BRIEF.md section 6, weights 25/25/15/10/10/10/5) against the same brief as
the studio designs. Read off the drawings, ± 0.1 m.

## What all five share
- Master bedroom (king, garden side), master bath on the west wall (stack W1), a terrace door.
- The east garden room is a **"family living & kitchenette"** with an L-sofa — i.e. an upstairs living, which the brief
  says is not needed; it opens to the corridor, so it is not part of the master suite and there is no suite lounge.
- Kitchenette + laundry side by side at the living's door (≈ 0.7 + 1.1 m), WC/shower room for the living on stack E1.
- Kids: double bedroom east-street (4.5 × 3.9, twin beds 1.1 m with a shared nightstand, wardrobe wall on the north side,
  two desks) and "Kids play room / mini gym" west-street (3.84 × 3.83–4.12); kids bath (2.72 × 1.5–1.8) off the corridor.
- Christian prayer room with three or four seats in the west bay, middle.

## One by one

| # | Proposal | Big idea | Strengths | Problems | Score |
|---|---|---|---|---|---|
| O1 | KK 1 "family living" (refined KKK) | two separate dressings (his / hers) stacked between the master bath and the prayer room | clean, buildable, wet rooms on existing stacks, his and hers both closed | upstairs living outside the suite; kids bath only from the corridor (no inside doors); laundry 1.1 m; corridor runs 9 m | 64 |
| O2 | KK 2 "island dressing" | a walk-in dressing with a central island and a curved wall (east bay, 4.23 × 3.76) + a **family lounge in the middle of the west bay** with a curved L-sofa and a kitchenette bar | the most generous dressing of any drawing; the landing becomes a lounge (circulation doubles as a room) | two living rooms upstairs (brief: none); dressing is shared and walk-through; kids bath from the lounge; no suite door | 61.5 |
| O3 | KK 3 "swapped master" | master bedroom moves to the **east garden room with its own terrace door**; west garden room becomes a sitting room; island dressing with a curved wall in the west bay | bedroom opens straight onto the terrace; dressing between sitting room and bed; prayer room 2.64 × 1.68 | the family lounge again takes the landing; master bath is reached across the landing; kids bath from the corridor | 65 |
| O4 | Angles 1 "diagonal dressing" | a 45° dressing core (1.99 × 2.04 + angled wardrobe) with round corner niches turning the master passage | the most sculptural plan; master bath with a freestanding tub (brief: shower) | the angles leave triangles no furniture uses; long dark passage; prayer room in a 1.4 m strip; kids bath from the corridor | 58.5 |
| O5 | Angles 2 "curved prayer" | the prayer room's corridor wall is a **sweeping arc** (4 seats, apse feel) and the corridor kinks at 45° | best prayer room of any drawing; double-basin master bath 2.06 × 1.5; dressing 1.99 × 2.04 + 2.06 × 2.0 | still an upstairs living outside the suite; master bath with tub; kids bath from the corridor | 63.5 |

For comparison: studio H2 81, H3 80, T2-B 81, master as drawn 64.

## Ideas worth taking (and where they go)
1. **Living landing (O2, O3).** The landing beside the stair is circulation in every plan; O2/O3 furnish it as a family
   lounge. Taken in a lighter form: a built-in walnut bench + bookcase + small TV/kids' reading nook on the landing, so the
   space the house must give to circulation earns a job — no extra room, no change to the brief.
2. **Hers as an island dressing with a curved wall (O2, O3).** Where hers has ≥ 2.6 m clear width, a 0.9 × 1.4 island of
   drawers inside a curved-ended dressing; his stays a separate closed room (Daniel 19 Oct).
3. **Curved prayer wall (O5).** The arc on the corridor side gives the prayer room an apse and four seats facing the icon
   wall, and softens the corridor turn — combine with the studio's east icon wall.
4. **Twin beds with a shared nightstand on the east wall + wardrobe wall on the north (all five).** Already in the studio
   designs; the 1.1 m beds (vs our 1.0) are a nice upgrade where the room allows.
5. **Master bedroom on the terrace (O3).** An option for the suite: bedroom in the east garden room with the terrace door,
   sitting room / future child's room in the west garden room. Worth a variant if Daniel wants the bedroom on the terrace.
6. **Freestanding tub in the kids bath (O4/O5)** on the west wall with the window — if Daniel still wants a tub for small
   children, it fits a 1.5–1.8 m deep bath.

## Not taken
- An upstairs family living room outside the suite (brief: not needed; the suite lounge does the job and becomes a bedroom).
- Kids bath reached only from the corridor (Daniel: doors from inside the rooms).
- 45° walls that leave unusable triangles (O4) — the studio keeps diagonals only where they win floor (T2-D, H3).
