# C37-38 Design Studio — brief, site, space schedule and scorecard

Written 2026-10-18 from CLAUDE.md, DECISIONS.md and Daniel's answers of 2026-10-18 (23:39). This file is the yardstick every
concept in the studio is measured against. Daniel's brief is the brief: anything that challenges it lives in a separate
"challenge" iteration, never mixed into the main concepts.

Naming used everywhere in the studio: **garden side** (+Y, the big garden and open views) and **street side** (−Y, the
one-sided road and the entrance porch). Daniel calls the street side the front; older repo files call the garden side the
front. "Garden side / street side" removes the ambiguity.

## 0. Brief update, 19 Oct 2026 evening
- **23:05 (Daniel): the kids bathroom must be on an outside wall.** A kids bath in the middle of the floor is not an option for building; T2-B, H1, H2, H3 and H4 (which share that kids wing) are kept as ideas only. (Daniel, after seeing the office plans in studio style)
- **Master suite style stays**: a closed suite (bedroom + dressings + shower room, ideally with a lounge) is wanted.
- **Two children's rooms are acceptable**: e.g. one double kids room (two children) + a play room that later becomes a bedroom.
  Equal m² per child is no longer a hard requirement.
- **An upstairs family living room is allowed** (the office's garden-east "family living & kitchenette"); down the road it can
  become a study or a play room.
- **The 45° kids bath with three doors between the two kids rooms (H4 / H3 / T2-B / H1 / H2) is rejected** ("this bathroom will
  not be applicable").
- **Scoring changes**: Daniel's requirements are at most about half of the weight; the other half is engineering quality and
  ease of living (use of space, movement, buildability, light, storage, proportion, adaptability). Each plan is also read for
  where it shines, so the best parts can be combined.

- **Update 19 Oct, 20:04 (Daniel), for hybrids H5 / H6:**
  - no separate family living; a **suite lounge for the master only**, joined to the sleeping area by a **wide sliding wall**,
    with **its own bathroom** (so in ~15 years it becomes a bedroom; its corridor door is built now as a hidden / pocket door);
    a smaller sleeping area is fine (≥ 12–13 m² for a king bed) if the suite as a whole is bigger;
  - the master suite has its own shower room as well → two bathrooms in the suite;
  - keep the office's **stacked laundry with the built-in kitchenette** at the landing;
  - the **prayer room needs no daylight** (inner room, quiet extract fan for candles / incense);
  - **every toilet on an outside wall at a drain stack** (W1, W2, E1);
  - **separate his (closed) + hers (larger, island + curved wall)** dressings;
  - **a kids wing**: double kids room + play room, the kids bath off the wing's own corridor, the same access for both rooms;
  - Daniel likes the office's **curves and 45° angles** (keep them in dry walls and joinery; wet rooms straight).

## 1. Site and climate

- **Orientation** (Daniel, Google Maps 2026-10-18): the garden side faces roughly **north**, turned slightly off true north.
  So the street side faces south, the left side (−X) faces west, the right side (+X) faces east.
- **Sun.** Cairo, 30° N. The street side takes the sun all day: high and easy to shade in summer, low and welcome in winter.
  The garden side gets soft north light all year and direct sun only on summer mornings and evenings. The side walls face
  neighbouring villas about 6 m away (two storeys), which shade most of the low east and west sun, especially downstairs.
- **Air.** The prevailing Cairo breeze is north to north-west, so it comes **from the garden**. Rooms that open to the garden
  and also have a window or door toward the street get cross-ventilation; that is the best place for the main living space
  and the master bedroom.
- **Noise and privacy.** The street is a small one-sided road; the garden side looks onto open views and a large garden.
  Neighbours on both sides at similar distances: side windows are for light and air, not views.
- **Compound rules:** AC outdoor units and the kitchen exhaust go on the **side facades**. Side-window changes can be
  negotiated (done at the end). The garden and street facades never change.

## 2. Fixed shell (out/studio/base_check.png)

- Envelope 9.09 × 18.35 m, ground floor FFL 0.00, first floor +3.45, clear height 3.20, slab 0.25.
- **Columns** (concrete, untouchable), three lines along the length of the house:
  west line X ≈ −105.2 (Y +8.0, +6.1, +1.0, −4.1, −9.9); **middle line X ≈ −101.2** (Y +8.0, +6.1, −1.3, −4.4, −8.0, −9.9);
  east line X ≈ −96.8 (Y +7.8, +5.9, +0.3, −3.9); porch pier (−97.4, −9.5) ground only.
  The middle line splits the house into a **west bay ≈ 3.9 m** and an **east bay ≈ 4.4 m** clear.
- **Stair** (concrete U-stair with a square well): X −99.5…−96.55, Y −3.85…+0.25. It starts at the hall on the ground floor
  and arrives at the top-left on the first floor, facing the middle corridor strip (X −101.1…−99.5, 1.6 m wide).
- **Outdoor areas that stay:** ground garden terrace (west bay, Y +6.0…+8.3), entrance porch (east bay, Y −10.1…−8.0);
  first-floor garden terrace (east bay, Y +6.05…+8.3), rear roof over the porch (east bay, Y −10.1…−8.0).
- **Openings that stay** (garden and street facades): ground garden sliders (west bay to the terrace, east bay to the
  garden), street-side kitchen/pantry window, entrance door; first-floor master window (west bay, garden), slider east bay
  to the terrace, master terrace door, both street-side windows (west bay and east bay over the roof).
- **Wet areas:** first-floor wet rooms anywhere except on the garden side; ground-floor fixtures near the existing drains
  (kitchen west-street, guest toilet east-street) so drains run in the screed without cutting concrete.

## 3. Household and life stages (Daniel, 2026-10-18)

| Stage | Years (from marriage, 2027) | Who lives upstairs | What the floor must do |
|---|---|---|---|
| **1 — Couple** | 0 → ~4 | Daniel + Karen | The garden half is a **hotel-style private suite**: bedroom + suite lounge + his and hers dressing + shower room. The street half is quiet: playroom, guest use, parents visiting. |
| **2 — Young family** | ~4 → ~14 | + 1–2 children | First child in the **double room**, the sibling joins later. Playroom in use. Suite lounge still the couple's. |
| **3 — Older children** | ~14 → | + up to 3 children | Children move apart, or a third arrives: the playroom / modular room and, if needed, the suite lounge become bedrooms **with no building work**. Every child gets **similar m² per person and similar toilet access**. |

Other facts: no nanny or helper ever; no guest bedroom (parents visiting use a kids room); no home office or study (use the
space for something else); everything bought new; ceiling ≈ 3.3 m to the slab, flat slab, almost no beams.

## 4. Space schedule (net m², targets; drawn with real furniture)

### Ground floor (≈ 125 m² inside the walls)
| Space | Target | Must contain | Notes |
|---|---|---|---|
| Vestibule + entrance hall | 6–10 | coats + shoes cupboard ≥ 1.8 m, bench, mirror | first thing guests see; a closable line between guests and family |
| Guest WC | 2.0–3.0 | WC + basin | door off the hall, not facing the seating |
| Living (family + guests) | 24–32 | sofas for **6–7**, TV facing the seating, coffee table | garden side, cross-ventilated, cosy, not a hall |
| Dining | 8–12 | table for **4–5** (6 at a push), sideboard | serves both family and guests; next to the kitchen |
| Kitchen (open American) | 14–20 | 60/80 cm appliances, **strong hood**, breakfast seating 2–3 | **movable partition** to close it for guests or smells |
| Walk-in pantry | 3–5 | shelves ≥ 1.9 m wide both sides or ≥ 1.5 m one side | straight off the kitchen |
| Storage | 2–5 | under the stair + a store with an outside door | bulk items also go to the garden shed |
| Circulation | ≤ 15 % of the floor | | |

### First floor (≈ 120 m² inside the walls)
| Space | Target | Must contain | Notes |
|---|---|---|---|
| Master bedroom | 16–20 | **king bed 1.93 × 2.03** (+ headboard), two bedside tables, 0.7 m beside, 1.0 m at the foot, a chair | garden side |
| Master shower room | 5–7 | walk-in shower ≥ 0.9 × 1.4 (no tub), WC, double basin preferred | inside the suite |
| Hers dressing | 5–8 | ≥ 3.5 m of wardrobe + full mirror | larger than his |
| His dressing | 3–5 | ≥ 2.0 m of wardrobe | |
| Suite lounge → future bedroom | 12–16 | sofa / chaise, TV; later a bed | door from the suite AND from the corridor (lockable) |
| Double kids room | 13–16 | **two beds 1.0 × 2.0**, two desks, 2.4 m wardrobe | stage 2 |
| Second kids room / playroom | 10–14 | play now; later 1 bed + desk + 1.2 m wardrobe | stage 3 bedroom |
| Kids bath | 4–6 | shower or tub, WC, basin (twin if room) | door inside each kids room where possible |
| Secret playroom | — | hidden door | fun, not a must if it costs a bedroom |
| Prayer room (Christian) | 3–5 | icon wall on the east side, candle shelf, 2–3 seats or kneeler | quiet, off the corridor |
| Laundry + linen | 3–5 | washer + dryer (side by side 1.4 m, or stacked), folding counter, linen shelves, ironing | central |
| Kitchenette | 1.2–2 m run | coffee, drawer fridge, small sink | outside the master suite, at the landing |
| Circulation | ≤ 15 % | | |

## 5. Adjacencies and zoning

Ground floor:
- Porch → vestibule → hall. From the hall, guests reach the **living, the dining and the guest WC** without passing the
  kitchen work zone, a family-only door or the stair landing.
- Kitchen ↔ pantry: direct. Kitchen ↔ dining: direct (serve without crossing the living). Kitchen ↔ outside / store: short
  service route for groceries and rubbish that does not cross the guest seating.
- Kitchen ↔ hall / living: open, with a **movable partition** that closes the kitchen completely.
- Stair: from the hall, ideally not the first thing in the guest seating's view.
- Living ↔ garden: the sliders and the terrace.

First floor:
- **Parents' wing = garden half**, behind ONE suite door: bedroom, dressings, shower room, suite lounge.
- **Kids' wing = street half**: kids rooms, kids bath (doors from inside the rooms), playroom.
- **Shared heart at the stair landing**: kitchenette, laundry, prayer room, linen; reachable from both wings without
  entering either.
- At stage 3 the suite lounge must be reachable from the corridor without going through the master bedroom.

## 6. Scorecard (how the studio judges; Daniel 2026-10-18: "best use of space, modular, well thought out" wins)

| # | Criterion | Weight | Measured by |
|---|---|---|---|
| 1 | **Use of space** | 25 | circulation %, dead corners, every m² has a job (Karen's rule), schedule targets met |
| 2 | **Modularity / life stages** | 25 | stages 1-2-3 work with no building work; child equity (m² per child, toilet access) |
| 3 | **Flow and privacy** | 15 | guest route, the two wings, the adjacency list above |
| 4 | **Storage** | 10 | wardrobe metres per person, pantry, store, linen, under-stair |
| 5 | **Light, air and orientation** | 10 | garden-side rooms, cross-ventilation, daylight in every habitable room |
| 6 | **Buildability and cost** | 10 | new walls, moved wet points, facade changes needing approval |
| 7 | **Sense of space** | 5 | sightlines, ceiling height used, curves and generosity where they count |

Pretty renders come later; the score is on the plan.
