# C37-38 · Design studio package · 2026-11-01

For the architects of Daniel and Karen's villa (unit C37-38, Stone Park). Everything the design studio produced, ready to develop further.

## What is inside

| Item | What |
|---|---|
| 01_all-sheets.pdf | every concept: plan sheet (both floors + story), the first floor at three life stages, and the movement check |
| 02_area-schedule.csv | every room of every concept with its area and clear size |
| concepts/<ID>/<ID>.dxf | the concept in AutoCAD (see layers below) |
| concepts/<ID>/*.png, sheet.pdf | the same drawings as images |
| concepts/<ID>/<ID>.yaml | the concept's source (rooms, doors, furniture in metres) |
| brief/ | the brief and space schedule, the five-reviewer council, the recommendation, the scores, the decision log |
| source/ | the master DXF the concepts sit on (C37-38 FINAL), the developer DXF, and the reference PDFs |

## Concepts (score / 100 on the brief's weighted scorecard)

| ID | Title | Score |
|---|---|---|
| F1-3 | F1 resolved — every open point decided | – |
| F1 | Near-final — 31 Oct (Rev 07) | – |
| F1-1 | Daniel's plan, detailed — A (quiet) | – |
| F1-2 | Daniel's plan, detailed — B | – |
| D1 | Daniel's plan — 22 Oct | – |
| D1-A | Daniel's Direction A | – |
| D1-B | Daniel's Direction B | – |
| H6-1 | H6 · iteration 1 — wet wall west | – |
| H6-2 | H6 · iteration 2 — prayer at the landing | – |
| H5 | The office, finished | 76.8 |
| H6 | T1-R1, softened | 76.2 |
| H4 | H2 + the office's ideas | 82.5 |
| H2 | Your master downstairs · Equal thirds upstairs | 81.0 |
| H3 | Folded suite · equal kids | 80.0 |
| H1 | Family side · Guest side downstairs · Equal thirds upstairs | 78.5 |
| T1-R3 | Master plan, round 3 — off the grid where it pays | 76.0 |
| T1-R2 | Master plan, round 2 — the suite and the stair top | 74.0 |
| T1-R2W | Round 2 + guest WC with an outside door | 73.0 |
| T1-R1 | Master plan, round 1 — the council's fixes | 72.0 |
| T1-X | Challenge the brief | 76.0 |
| T2-A | Family side · Guest side | 75.0 |
| T2-B | Equal thirds | 81.0 |
| T2-C | Soft courtyard | 71.0 |
| T2-D | Folded house | 74.5 |
| T0 | Master plan as drawn (baseline) | 64.0 |
| O1 | Office KK 1 — family living | 51.5 |
| O2 | Office KK 2 — island dressing | 56.0 |
| O3 | Office KK 3 — master on the terrace | 52.2 |
| O4 | Office Angles 1 — diagonal dressing | 53.8 |
| O5 | Office Angles 2 — curved prayer room | 54.5 |

## Coordinates and layers (DXF)

- Metres, the SAME coordinates as the developer drawing: the ground floor sits on the developer's ground floor; the first floor is drawn beside it at X − 11.42, as in the developer DWG, so each DXF can be overlaid on your files directly.
- +Y is the GARDEN side (north), −Y the STREET / entrance side.
- Fixed: columns, slabs, the stair, the garden and street facades. Side facades only with the compound's approval (items marked DN / in NOTES).
- Layers: S-FACADE fixed facade walls · S-COLS columns · **A-ROOM-CL each room as a closed polyline on the wall CENTRE-LINES (the design intent; redraw true walls from these)** · A-WALL-NEW generated 0.12 m partitions · A-GLAZ-PART glass / movable partitions · A-HALF half walls · A-RAIL stair balustrade · A-DOOR doors (D swing, DD double, SL slide, PK pocket, BF bifold, PV pivot, OP opening, with width) · A-WIND facade openings (S slider, W window, D door, DN new door) · A-STAIR · I-FURN furniture (life stage 2) · A-ROOM-TEXT names and areas · A-NOTE.
- Walls on A-WALL-NEW come from a 1 cm raster: diagonal and curved walls are faceted. Use A-ROOM-CL for exact geometry.

## Things to verify on site before developing

- The three first-floor drainage stacks (W1 west wall Y≈−1.0, W2 west wall Y≈−4.9, E1 east bay Y +0.3…+2.0) and where E1 lands on the ground floor.
- Any concept that places a first-floor wet room off those stacks says so in its NOTES (raised-floor run or new chase).
- Side-facade changes (new/moved windows, the guest-WC outside door) need the compound's written approval.
- Kitchen hood exhaust and AC outdoor units go on the side facades (compound rule).

## Life stages (why every first floor is shown three times)

Stage 1: the couple (garden half is a hotel-style suite with a lounge). Stage 2: one or two young children in the street half. Stage 3: up to three older children; the suite lounge and the playroom become bedrooms with no building work, every child with similar m² and toilet access.

Live page with 3D walk-throughs: https://danieldoss2000-dot.github.io/c37-site/studio/